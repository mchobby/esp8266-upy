This folder contains a copy of the dependencies library used in this project
